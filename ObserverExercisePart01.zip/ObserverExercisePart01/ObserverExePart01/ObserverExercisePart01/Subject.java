package ObserverExercisePart01;

// Editora
public interface Subject {
	
	
}
