package ObserverExercisePart01;

public interface Observer {
	public void update (Entregavel pEntregavel);
}
