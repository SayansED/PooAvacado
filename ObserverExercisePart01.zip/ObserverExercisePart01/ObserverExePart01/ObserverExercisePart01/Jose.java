package ObserverExercisePart01;

public class Jose extends Pessoa {
	JornalEstadao jornalEstadao = new JornalEstadao();
	jornalEstadao.assinaturaDiaria();
	jornalEstadao.assinaturaFinaisSemana();
}
