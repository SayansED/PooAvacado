package ObserverExercisePart01;

public abstract class Pessoa implements Observer{
	

}
