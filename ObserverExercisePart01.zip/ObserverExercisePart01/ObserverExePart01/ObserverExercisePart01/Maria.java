package ObserverExercisePart01;

public class Maria extends Pessoa {
	RevistaMarie revistaMarie = new RevistaMarie();
	revistaMarie.assinaturaSemanal();
}
