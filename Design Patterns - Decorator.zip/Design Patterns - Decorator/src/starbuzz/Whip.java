package starbuzz;

public class Whip extends CondimentDecorator {

	public Whip (Beverage b) {
		super (b);
	}
	
	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return getBerage() == null ? 2.9 : getBerage().cost() + 2.9;
	}

}
