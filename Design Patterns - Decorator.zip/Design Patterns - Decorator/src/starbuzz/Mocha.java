package starbuzz;

public class Mocha extends CondimentDecorator {
	
	public Mocha (Beverage b) {
		super (b);
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return getBerage() == null ? 2.1 : 2.1 + getBerage().cost();
	}

}
