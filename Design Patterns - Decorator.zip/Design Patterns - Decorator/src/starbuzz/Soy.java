package starbuzz;

public class Soy extends CondimentDecorator {
	
	public Soy (Beverage b) {
		super (b);
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return getBerage() == null ? 0.3 : 0.3 + getBerage().cost();
	}

}
