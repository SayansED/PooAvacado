package starbuzz;

public abstract class CondimentDecorator extends Beverage {
	
	// Todas decorator tem em comum
	private Beverage beverage;
	
	public CondimentDecorator(Beverage beverage) {
		this.beverage = beverage;
	}

	public Beverage getBerage() {
		return beverage;
	}
	
	public void setBeverage(Beverage beverage) {
		this.beverage = beverage;
	}
	
	@Override
	public String getDescription() {
		return beverage == null ? super.getDescription() : super.getDescription() + ", " + beverage.getDescription();
	}
}
