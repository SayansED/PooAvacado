package starbuzz;

public class Espresso extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 13.9;
	}

}
