package starbuzz;

public abstract class Beverage {
	
	public abstract double cost();
	
	public String getDescription() {
		return getClass().getSimpleName();
	}
}
