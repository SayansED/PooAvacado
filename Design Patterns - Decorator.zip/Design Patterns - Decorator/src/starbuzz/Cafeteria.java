package starbuzz;

import java.text.NumberFormat;

import javax.swing.JOptionPane;

public class Cafeteria {

	public static void main(String[] args) {

		Beverage b = null;
		NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
		
		String menuBebidas = "1-HouseBlend"
				+ "\n"
				+ "2-DarkRoast"
				+ "\n"
				+ "3-Decaf"
				+ "\n"
				+ "4-Espresso"
				+ "\n";

		String menuCondimentos = "0-Sair"
				+ "/n"
				+ "1-Milk"
				+ "\n"
				+ "2-Soy"
				+ "\n"
				+ "3-Mocha"
				+ "\n"
				+ "4-Whip"
				+ "\n";

		int opcaoBebida = Integer.parseInt(JOptionPane.showInputDialog(menuBebidas));

		switch (opcaoBebida) {
		case 1:
			b = new HouseBlend();
			break;
		case 2:
			b = new DarkRoast();
			break;
		case 3:
			b = new Decaf();
		case 4:
			b = new Espresso();
			break;
		}

		int opcCondimento;

		do {
			opcCondimento = Integer.parseInt(JOptionPane.showInputDialog(menuCondimentos)); 
			switch (opcCondimento) {
			case 0:
				System.out.println(b.getDescription());
				System.out.println(currencyFormat.format(b.cost()));
				break;
			case 1:
				b = new Milk (b);
				break;
			case 2:
				b = new Soy (b);
				break;
			case 3:
				b = new Mocha (b);
				break;
			case 4:
				b = new Whip (b);
				break;
			}
		} while (opcCondimento != 0);
	}

}
