package starbuzz;

public class HouseBlend extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 7.7;
	}

}
