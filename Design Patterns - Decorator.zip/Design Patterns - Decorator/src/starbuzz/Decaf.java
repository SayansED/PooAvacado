package starbuzz;

public class Decaf extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 5.4;
	}

}
