package ExercicioFigurasGeometricas;

public class Retangulo extends FigurasGeometricas {

	@Override
	public String getDescription() {
		return getClass().getSimpleName();
	} 
}
