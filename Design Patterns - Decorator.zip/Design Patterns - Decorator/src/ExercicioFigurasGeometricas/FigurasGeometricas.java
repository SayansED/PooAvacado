package ExercicioFigurasGeometricas;

public abstract class FigurasGeometricas {
	
	// M�todo para informar o usuario
	public String getDescription() {
		return getClass().getSimpleName();
	}
	
}
