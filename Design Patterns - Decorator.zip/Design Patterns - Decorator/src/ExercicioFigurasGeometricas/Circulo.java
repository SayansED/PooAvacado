package ExercicioFigurasGeometricas;

public class Circulo extends FigurasGeometricas {
	
	@Override
	public String getDescription() {
		return getClass().getSimpleName();
	} 
}
