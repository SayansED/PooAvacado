package ExercicioFigurasGeometricas;

public class Quadrado extends FigurasGeometricas {
	
	@Override
	public String getDescription() {
		return getClass().getSimpleName();
	} 
}
