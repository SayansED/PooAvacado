package old;

public class Decaf extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 6.3;
	}

}
