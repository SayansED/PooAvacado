package old;

public class HouseBlend extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 8.9 + (isHasMilk() ? 2.3 : 0) + (isHasMocha() ? 3.2 : 0);
	}
}
