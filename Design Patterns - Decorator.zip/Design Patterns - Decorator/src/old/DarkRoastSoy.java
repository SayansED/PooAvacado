package old;

public class DarkRoastSoy extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 9.9 + 3.2;
	}

}
