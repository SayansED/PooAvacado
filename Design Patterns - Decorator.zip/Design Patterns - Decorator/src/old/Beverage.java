package old;

public abstract class Beverage {
	
	private String description;
	
	private boolean hasMilk;
	private boolean hasSoy;
	private boolean hasMocha;
	private boolean hasWhip;
	
	public boolean isHasMilk() {
		return hasMilk;
	}
	public void setHasMilk(boolean hasMilk) {
		this.hasMilk = hasMilk;
	}
	public boolean isHasSoy() {
		return hasSoy;
	}
	public void setHasSoy(boolean hasSoy) {
		this.hasSoy = hasSoy;
	}
	public boolean isHasMocha() {
		return hasMocha;
	}
	public void setHasMocha(boolean hasMocha) {
		this.hasMocha = hasMocha;
	}
	public boolean isHasWhip() {
		return hasWhip;
	}
	public void setHasWhip(boolean hasWhip) {
		this.hasWhip = hasWhip;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public abstract double cost ();
}
