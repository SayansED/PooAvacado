package old;

public class DarkRoastMilk extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 9.9 + 2.3;
	}

}
