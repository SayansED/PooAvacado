package old;

public class DarkRoastWhip extends Beverage {

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 9.9 + 4.4;
	}

}
